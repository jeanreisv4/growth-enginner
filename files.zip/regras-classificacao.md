# Regras de Classificação de Criativos

Esta referência define **como classificar criativos** entre vencedor, manter, revisar/reduzir
ou pausar — e qual ação recomendar pra cada caso. Toda comparação aqui é sempre **contra a
projeção**, nunca contra benchmark de mercado ou média do dataset.

---

## Hierarquia de proximidade da receita (régua mestra)

Quando dois sinais brigam — por exemplo, criativo com CPL bom mas CTR ruim — sempre prevalece
a métrica **mais próxima da receita**. Esta é a hierarquia, da menos relevante pra mais
relevante:

```
CPM → CTR → CPC → CPLPV → CPL → CPMQL → CPSQL → CAC → ROAS / ROI
```

**Lógica:** CPM mede custo de impressão (longe da receita). ROAS mede retorno sobre
investimento (a receita já aconteceu). Quanto mais à direita na régua, mais a métrica
representa receita real.

**Aplicação prática:**
- Criativo com CTR ruim mas CPL bom vs projeção → **classifica pelo CPL**, é vencedor
- Criativo com CPL bom mas CPMQL alto vs projeção (Modo B) → **classifica pelo CPMQL**,
  é a revisar (lead barato mas ruim)
- Criativo com CPC alto mas CPMQL bom vs projeção (Modo B) → **classifica pelo CPMQL**,
  é vencedor (público pequeno mas qualificado)

---

## Critério de classificação: VENCEDOR

Criativo vencedor é aquele que **destrava receita acima do projetado**. Para classificar
como vencedor, o criativo precisa combinar simultaneamente:

### Condições obrigatórias (todas)

1. **Volume relevante** — número de leads (ou MQL em Modo B) suficiente pra não ser ruído
   estatístico. Se for amostra pequena mas o resultado for muito acima da projeção,
   classifica como "vencedor preliminar — sem amostragem suficiente, validar com mais dado".

2. **Métrica mais próxima da receita disponível abaixo da projeção:**
   - **Modo A:** CPL abaixo da projeção
   - **Modo B:** CPMQL abaixo da projeção (mesmo se CPL estiver dentro/acima)

3. **Sinais coerentes upstream:**
   - Boa Taxa Cliques → Lead vs projeção
   - CTR, CPC e LPV em níveis aceitáveis vs projeção (não precisam ser ótimos, mas não
     podem estar muito abaixo)

### Ação recomendada para vencedor

| Situação                                                   | Ação                  |
|------------------------------------------------------------|-----------------------|
| Vencedor sem sinal de fadiga, com headroom de orçamento    | **Escalar**           |
| Vencedor performando bem, sem fadiga, sem headroom         | **Manter**            |
| Vencedor com frequência alta começando a subir             | **Duplicar variações** |
| Vencedor com volume baixo mas resultado acima da projeção  | **Escalar com cautela** + observar amostragem |

---

## Critério de classificação: REVISAR / REDUZIR / PAUSAR

Criativo a revisar é aquele que **trava receita ou queima orçamento sem retorno**. Basta
**um** dos sinais abaixo pra classificar como tal:

### Sinais (qualquer um)

1. Gasto relevante (>5% do investimento total da campanha) **sem lead**
2. CPL acima da projeção (em Modo A)
3. CPMQL acima da projeção (em Modo B — prevalece sobre CPL pela hierarquia)
4. Baixa Taxa Cliques → Lead vs projeção
5. **Fadiga por frequência** — frequência alta vs projeção combinada com queda de CTR ao
   longo do período
6. CTR baixo + CPC alto vs projeção
7. **Desalinhamento promessa-página/formulário** — alto CTR mas baixíssimo Taxa Visita→Lead
   (visitante chega mas desiste rápido)
8. Em Modo B: CPMQL alto mesmo com CPL ok (lead chega barato mas é ruim — qualidade do
   público errada)

### Ação recomendada — escolha uma com base no diagnóstico

| Diagnóstico                                                | Ação                       |
|------------------------------------------------------------|----------------------------|
| CTR ruim, CPC alto                                         | **Revisar criativo**       |
| CPMQL alto com CPL ok (Modo B)                             | **Revisar público**        |
| Alto CTR + baixa Taxa Visita→Lead                          | **Revisar página/formulário** |
| Frequência alta + CTR caindo                               | **Pausar** + duplicar variações de outros criativos |
| Performance moderadamente abaixo, com algum sinal positivo | **Reduzir orçamento**      |
| Performance muito abaixo, sem sinal de recuperação         | **Pausar**                 |
| UTMs incompletas, conversão off, dados inconsistentes      | **Revisar tracking**       |

---

## Critério de classificação: MANTER

Criativo a manter é aquele que **performando dentro da projeção, sem sinal de fadiga**.

### Condições

- Métricas próximas à receita (CPL ou CPMQL) **dentro da projeção** (±10% de variação)
- Sem sinal de fadiga (frequência estável, CTR estável)
- Volume estável

### Ação

**Manter** sem mexer no orçamento, mas **monitorar fadiga** semanalmente.

---

## Caso especial: amostra pequena

Quando um criativo tem volume baixo (definição depende do contexto, mas geralmente <10% do
volume médio dos demais criativos da campanha), os sinais perdem confiança estatística.

**Como tratar:**
- Inclua o criativo na análise mas marque com flag "sem amostragem suficiente"
- Não classifique definitivamente como vencedor ou revisar
- Recomende ação de "validar com mais investimento por X dias" antes de decisão final

---

## Caso especial: criativos novos vs antigos

Criativo recém-subido (menos de 7 dias rodando) ainda está em **fase de aprendizado** do
Meta. Sinais nesse período são instáveis.

**Como tratar:**
- Sinalize criativos novos com flag "em fase de aprendizado"
- Não classifique como pausar antes de 7 dias mesmo que CPL esteja alto
- Compare com a projeção mas pondere a leitura

---

## Resumo: ações possíveis (vocabulário fixo)

Toda classificação termina com **uma** dessas ações:

- **Escalar** — aumentar orçamento (vencedor com headroom)
- **Manter** — sem mexer (dentro da projeção)
- **Reduzir** — diminuir orçamento (abaixo da projeção mas com sinal aproveitável)
- **Pausar** — desligar (muito abaixo, sem recuperação)
- **Duplicar variações** — criar novas peças mantendo público/oferta (fadiga próxima)
- **Revisar criativo** — refazer peça (problema de CTR/copy/imagem)
- **Revisar público** — trocar/refinar audiência (CPMQL alto)
- **Revisar página/formulário** — corrigir downstream (alto clique, baixa conversão)
- **Revisar tracking** — corrigir UTMs/eventos/conversão (dados inconsistentes)
- **Validar com mais dado** — amostra pequena ou criativo novo (não decidir ainda)
