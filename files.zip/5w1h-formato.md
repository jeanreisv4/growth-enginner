# Formato do Plano 5W1H de 7 Dias

Esta referência define **exatamente como construir** o plano 5W1H que fecha todo relatório.
O 5W1H é o entregável de ação da skill — sem ele, o diagnóstico não vira execução.

---

## Estrutura obrigatória

**Tabela com 7 colunas, nesta ordem exata:**

| What | Why | Where | Who | When | How | Impacto esperado |
|------|-----|-------|-----|------|-----|------------------|

A coluna "Impacto esperado" não é opcional — sem ela o plano vira lista de tarefas sem
priorização. Toda ação precisa declarar o resultado projetado.

---

## Quantidade de ações

**Entre 3 e 7 ações**, priorizadas por impacto em receita.

Regras:
- A **ação #1 sempre ataca a restrição global** identificada no diagnóstico
- Ações #2-#4 atacam restrições locais top 3
- Ações #5+ são de subordinação ou elevação (TOC), incluídas só se forem genuinamente
  críticas pra destravar receita
- **Não force 7 ações.** Se forem só 4 que importam, são 4. O nome "7 dias" é a janela
  temporal, não o número de ações.

---

## Conteúdo de cada coluna

### What
**Ação concreta, verbo no infinitivo.** Não pode ser vaga.

✅ Bom: "Pausar 4 criativos com CPMQL > 2x projeção"
✅ Bom: "Subir 3 variações de copy do criativo-mãe vencedor com novos ganchos de benefício"
❌ Ruim: "Otimizar campanha"
❌ Ruim: "Melhorar criativos"

### Why
**Vínculo direto com a restrição identificada no diagnóstico.** Cada ação precisa explicar
*por que ela existe* em termos da restrição que ataca.

✅ Bom: "CPMQL 2,3x acima da projeção indica público errado nos 4 criativos identificados"
✅ Bom: "Escala por criativo está cega sem UTM correta — restrição #1 do diagnóstico"
❌ Ruim: "Pra melhorar performance"
❌ Ruim: "Otimizar resultados"

### Where
**Onde executar a ação.** Específico — qual ferramenta, qual campanha, qual área.

Exemplos válidos:
- "Meta Ads — campanha [nome]"
- "Página de captura `/lp-orcamento`"
- "Formulário Lead Ads do conjunto X"
- "Pipeline Marketing no CRM"
- "Workflow do GTM"
- "Conjunto [nome] da campanha [nome]"

### Who
**Quem executa.** Use papel/função, não nome próprio (a skill não conhece o time do cliente).

Vocabulário sugerido:
- Media Buyer (gestor de tráfego)
- Designer/Editor
- Copywriter
- Growth Ops
- CRM Owner
- SDR / Inside Sales
- Analyst (você ou alguém de dados)
- Reporting

Quando a ação exige duas funções (ex: designer cria + media buyer sobe), separe com `/`:
"Designer / Media Buyer".

### When
**Janela em dias.** Use formato D1, D1-D2, D1-D7.

Convenções:
- D1 = primeiro dia útil após a entrega do relatório
- D1-D2 = ação rápida (até 48h)
- D3-D5 = ação que precisa de preparo (criativos novos, ajustes técnicos)
- D1-D7 = ação contínua durante toda a janela (ex: monitoramento, reporting)

Não use datas absolutas (1/maio, 5/maio) — o plano precisa ser portátil.

### How
**Instrução tática E estratégica simultaneamente.**

Tática: o passo a passo concreto.
Estratégica: o ângulo, a hipótese, o critério de sucesso.

✅ Bom (tática + estratégia): "Subir 3 variações testando ângulo de benefício 'economia de
tempo' com formato Reels 9:16, mantendo público vencedor [nome]. Critério de sucesso:
CPMQL ≤ projeção em 7 dias."

❌ Ruim (só tática): "Subir 3 criativos novos"
❌ Ruim (só estratégia): "Testar novo ângulo de comunicação"

A skill **direciona o que mudar e como medir** — mas **não inventa copy nem conceito
criativo**. Ela diz "testar ângulo X com formato Y", não escreve a copy em si.

### Impacto esperado
**Resultado projetado, preferencialmente em receita ou métrica próxima.** Quantitativo
sempre que possível.

✅ Bom: "Reduzir CPMQL de R$ 142 para R$ 95 (projeção), liberando 30 MQLs adicionais/mês
≈ R$ 15.000 de receita projetada"
✅ Bom: "90%+ oportunidades com origem acionável → escala por criativo deixa de ser cega"
❌ Ruim: "Melhorar resultados"
❌ Ruim: "Performance maior"

---

## Exemplo completo (modelo de referência)

| What                                              | Why                                                  | Where                       | Who              | When  | How                                                                                                                                          | Impacto esperado                                                                |
|---------------------------------------------------|------------------------------------------------------|-----------------------------|------------------|-------|----------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------|
| Corrigir UTMs faltantes nos anúncios ativos       | Tracking quebrado é restrição #1 — sem UTM, escala por criativo é cega | Meta Ads — todos os anúncios | Media Buyer / Growth Ops | D1-D2 | Persistir utm_campaign, utm_term, utm_content, fbclid e ad id em todos URLs. Validar em 100% antes de subir nova fase                       | 90%+ oportunidades com origem acionável                                          |
| Pausar 4 criativos com CPMQL > 2x projeção        | Restrição local #1 — esses 4 representam 38% do gasto e 0 MQL útil  | Meta Ads — campanha [X]     | Media Buyer      | D1    | Pausar criativos [IDs]. Realocar orçamento pros criativos vencedores [IDs]                                                                  | Reduzir CPMQL médio de R$ 142 para R$ 95, +30 MQLs/mês ≈ R$ 15k receita projetada |
| Subir 3 variações do criativo vencedor [nome]     | Vencedor com freq. 4,2 — fadiga próxima, criar lastro antes de fadigar | Designer / Media Buyer       | Designer / Media Buyer | D3-D5 | Manter público e oferta. Variar gancho (testar 'economia de tempo' / 'segurança' / 'autoridade') e formato (Reels 9:16, estática quadrada). Critério: CTR ≥ projeção em 7 dias | Estender vida útil do vencedor. Sustentar volume de MQL                          |
| Realocar 30% do orçamento dos pausados pros vencedores | Subordinação — após pausar gargalo, capital subutilizado precisa ir pros vencedores | Meta Ads — campanha [X]     | Media Buyer      | D2-D3 | Aumentar orçamento dos top 3 criativos vencedores em 30%. Monitorar CPMQL diariamente nos primeiros 3 dias                                  | +20-25% volume de MQL ao mesmo CAC                                               |
| Conciliação semanal Meta × CRM                    | Backup tem UTM, CRM tem etapa — sem cruzar, escala por criativo continua imprecisa | Reporting                    | Analyst          | D1-D7 | Rodar script de conciliação semanal cruzando Meta (gasto + leads) com CRM (MQL/SQL/Venda) por utm_content. Atualizar XLSX/HTML do reporting | MQL/SQL/Venda atribuíveis por criativo — base pra escala precisa                  |

---

## Regras invioláveis do 5W1H

1. **Toda ação se amarra a uma restrição.** Se uma ação não responde a um gargalo
   identificado no diagnóstico, ela não entra no plano.

2. **Ação #1 ataca a restrição global.** Sem exceção.

3. **Ordem de prioridade é por impacto em receita**, não por facilidade de execução.
   Se a ação mais difícil é a que destrava mais receita, ela é a #1.

4. **Impacto esperado é obrigatório**, quantitativo sempre que possível.

5. **Sem datas absolutas.** Use D1, D1-D2, D1-D7.

6. **Quem executa é por papel**, não por nome próprio.

7. **How precisa ter tática + estratégia.** Sem isso, vira lista de tarefas.

8. **A skill direciona, não inventa copy.** Ela diz "testar ângulo X", não escreve a copy.

9. **Se ações se contradizem** (ex: "pausar criativo Y" e "escalar criativo Y"), revise o
   diagnóstico — algo está errado upstream.

10. **Plano serve pra você e pra cliente.** Tom direto e profissional, com licença pra
    apontar desperdício quando os dados sustentarem ("queimando dinheiro com criativo
    fadigado há 30 dias" é legítimo se os dados mostram isso).
