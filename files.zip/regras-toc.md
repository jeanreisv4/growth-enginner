# Theory of Constraints (TOC) Aplicada ao Funil de Mídia

Esta referência define **como aplicar TOC** na identificação da restrição principal e das
restrições locais. A base teórica vem de Goldratt — "A Meta" — e a aplicação prática aqui é
adaptada pra contexto de Meta Ads em Inside Sales.

---

## Princípio fundamental

**Toda operação tem uma restrição.** Otimizar partes do sistema que não são a restrição
**não aumenta a receita**. Aumentar produtividade num lugar que já não é gargalo só infla
estoque (ou neste caso, leads desqualificados, criativos que não convertem, gasto sem
retorno).

A receita do sistema é determinada pelo gargalo. Logo:

1. **Identifique a restrição** (onde mais trava receita)
2. **Explore a restrição** (extraia o máximo dela com o que já tem)
3. **Subordine tudo à restrição** (alinhe o resto do sistema pra não desperdiçar)
4. **Eleve a restrição** (invista pra aumentar capacidade dela)
5. **Volte ao passo 1** (a restrição muda quando você a destrava)

Esta skill aplica os passos 1 e 2 explicitamente (identifica e explora) e sugere os passos
3, 4, 5 no plano 5W1H.

---

## Aplicação ao funil de Meta Ads

### O funil é uma sequência de capacidades

```
Investimento → Impressões → Cliques → Visitas → Leads → MQLs → SQLs → Vendas → Receita
```

Cada etapa tem uma capacidade própria, governada por:
- **Configuração de mídia** (orçamento, leilão, segmentação) — etapas 1-3
- **Criativo** (CTR, gancho, oferta) — etapas 2-4
- **Página/formulário** (LPV, conversão) — etapas 4-5
- **Qualidade do tráfego** (público, mensagem) — etapa 5-6
- **Operação comercial** (CRM, vendedores) — etapas 6-9

A restrição é o ponto onde **mais receita potencial é perdida** — não simplesmente onde a
taxa percentual é menor.

---

## Passo 1 — Identificar a restrição global

A restrição global é a que mais trava **receita**, não a que mais trava taxa percentual.

### Como calcular o impacto em receita por etapa

Pra cada etapa do funil, calcule o **gap vs projeção em volume final**:

```
gap_receita = (taxa_projetada_etapa - taxa_realizada_etapa) × volume_anterior × ticket_médio
```

Exemplo prático:
- Projeção: Taxa Lead → MQL = 30%, ticket médio = R$ 5.000, volume Lead = 1.000
- Realizado: Taxa Lead → MQL = 18%
- Gap em volume: (30% - 18%) × 1.000 = 120 MQLs perdidos
- Considerando taxa MQL → Venda projetada = 10%, perdemos 12 vendas
- Gap em receita: 12 × R$ 5.000 = **R$ 60.000 de receita perdida** nesta etapa

Faça isso pra cada etapa do funil. **A etapa com maior gap em receita é a restrição
global candidata.**

### Hierarquia desempata quando gaps são parecidos

Se duas etapas têm gap parecido em receita, prevalece a **mais próxima da receita** (ver
hierarquia em `regras-classificacao.md`). Isso porque destravar um gargalo upstream sem
resolver downstream só infla estoque.

Exemplo: se o gap em "Lead → MQL" e em "MQL → Venda" são parecidos, ataque "MQL → Venda"
primeiro — destravar Lead → MQL sem corrigir downstream só vai gerar mais MQLs travados.

### Frase-tese da restrição global

A restrição global vira o **título-tese do relatório**. Formato:

> "[Cliente]: [o que está sustentando] mas [restrição principal] — [direção da ação]"

Exemplos reais:
- "DPV: Google Ads sustenta o volume de MQL; a restrição geral migra para CRM, qualificação
  comercial e avanço pós-MQL"
- "Well Services: A restrição principal não é volume de leads; é atribuição e higiene do
  CRM para decidir escala por criativo"

**Se a tese não consegue ser formulada com clareza** (porque os dados são inconclusivos ou
porque há múltiplas restrições parecidas sem clara dominância), **TRAVA a análise** e
peça mais contexto/dado. Relatório sem tese é descrição.

---

## Passo 2 — Identificar restrições locais (top 3)

Restrições locais são gargalos **dentro** da restrição global, ou em pontos específicos do
funil que destravam volume sem ser a restrição #1.

### Critério

Liste as **3 restrições locais mais relevantes** por impacto em receita. Pode listar mais
se forem genuinamente críticas (4 ou 5 quando o caso é complexo). Não force 3 quando só 2
importam.

### Cada restrição local deve responder

1. **Onde está o gargalo** — etapa específica, criativo específico, público específico
2. **Por que está travando** — diagnóstico de causa
3. **Onde mexer primeiro** — ação concreta (subordinada à restrição global)
4. **Impacto esperado** — em receita, ou métrica próxima da receita

---

## Padrões comuns de restrição (catálogo)

Use estes padrões pra acelerar diagnóstico, mas **não force** um padrão se os dados não
sustentam.

### Padrão 1 — "Funil topo entupido"
**Sintoma:** muito investimento, muita impressão, mas poucos cliques.
**Restrição:** criativo (CTR baixo, ganchos fracos).
**Ação:** revisar criativos, subir variações com novos ângulos.

### Padrão 2 — "Funil meio vazando"
**Sintoma:** CTR ok, mas LPV baixo ou Taxa Visita→Lead baixa.
**Restrição:** página/formulário (carregamento, copy, fricção, mismatch promessa-página).
**Ação:** revisar página de destino e formulário.

### Padrão 3 — "Lead barato, MQL caro" (Modo B)
**Sintoma:** CPL ok ou abaixo da projeção, mas CPMQL muito acima.
**Restrição:** qualidade do público (atrai lead errado).
**Ação:** revisar segmentação, lookalikes, exclusões, oferta (talvez atraindo curioso e
não comprador).

### Padrão 4 — "MQL bom, venda travada" (Modo B com sinal de CRM)
**Sintoma:** CPMQL dentro da projeção mas conversão MQL → Venda muito abaixo.
**Restrição:** operação comercial (não é mídia).
**Ação:** sinalizar e direcionar pra `crm-inside-sales` pra análise profunda. Esta skill
não substitui análise de funil comercial.

### Padrão 5 — "Fadiga generalizada"
**Sintoma:** frequência alta em múltiplos criativos, CTR caindo ao longo do período,
CPL subindo.
**Restrição:** falta de variação criativa (público saturado dos criativos atuais).
**Ação:** subir múltiplas variações, pausar criativos mais fadigados.

### Padrão 6 — "Tracking quebrado"
**Sintoma:** UTMs incompletas, dados inconsistentes (mais leads que cliques, eventos sem
correspondência), MQL impossível de atribuir.
**Restrição:** observabilidade.
**Ação:** **isso é restrição #1 mesmo que outros gargalos pareçam maiores**, porque sem
dado confiável nada pode ser diagnosticado. 5W1H começa por corrigir tracking.

### Padrão 7 — "Conta queimando dinheiro"
**Sintoma:** múltiplos criativos com gasto relevante e zero/baixíssimo lead, ativos há
mais tempo que o ciclo de teste razoável (>14 dias).
**Restrição:** falta de governança operacional (ninguém está olhando os números).
**Ação:** pausar criativos zumbis, revisar rotina de gestão de campanha. Tom direto:
é legítimo apontar "esse cliente está queimando dinheiro com criativo fadigado há 30 dias"
quando os dados sustentarem.

---

## Como o diagnóstico vira plano de ação

A restrição global e as locais alimentam diretamente o **plano 5W1H** (ver
`5w1h-formato.md`). Regra:

1. A primeira ação do 5W1H **sempre ataca a restrição global**
2. As ações 2-4 atacam as restrições locais por ordem de impacto em receita
3. Ações 5+ podem ser de subordinação (ajustar outras partes do sistema à restrição) ou
   de elevação (investir em ampliar a capacidade da restrição)

**Nunca** liste no 5W1H ações que não estão amarradas a uma restrição identificada — vira
lista de tarefas, não plano de ataque.

---

## Princípio final

> "Diga-me como me medirás e eu te direi como me comportarei." — Goldratt

A medida nesta skill é **receita destravada por unidade de investimento**. Toda análise se
subordina a essa pergunta: onde mexer primeiro pra destravar mais receita? Tudo que não
responde isso é descrição.
