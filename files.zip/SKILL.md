---
name: meta-ads-inside-sales
description: >
  Diagnóstico completo de campanhas de Meta Ads para operações de Inside Sales orientado
  a receita. Use esta skill SEMPRE que o usuário enviar dados de Meta Ads (via MCP da Meta
  ou CSV exportado do gerenciador) junto com uma projeção de metas e quiser identificar a
  restrição principal do funil de mídia, classificar criativos vencedores e a revisar,
  diagnosticar gargalos de público/criativo/página, ou montar plano de ação 5W1H. Acione
  também quando o usuário pedir "análise de Meta Ads", "diagnóstico de campanha", "leitura
  de criativo", "por que meu CPL subiu", "qual criativo escalar", "análise de mídia",
  "Projetado vs Realizado de Meta", ou variações. A skill aplica Theory of Constraints (TOC)
  priorizando impacto em receita (CAC > CPSQL > CPMQL > CPL > CPC > CTR > CPM). Output:
  HTML autocontido com identidade visual fixa + planilha .xlsx estratificada + resumo em
  prosa no chat. NÃO use esta skill para análise profunda de CRM (use crm-inside-sales),
  análise de Google Ads (skill futura), criação de copy/criativos, ou projeção de mídia
  (use forecast-funnel-projections).
---

# Meta Ads Inside Sales — Diagnóstico de Mídia Orientado a Receita

## O que esta skill faz

Recebe dados brutos de Meta Ads (via MCP ou CSV) + projeção de metas em planilha modelo
(obrigatória) + opcionalmente CSV de CRM com UTMs. Executa diagnóstico estruturado aplicando
**Theory of Constraints** sobre o funil de mídia, classifica criativos por proximidade da
receita, identifica restrição global e as top 3 locais, e entrega três artefatos:

1. **Resumo em prosa no chat** — primeira pessoa de analista, 3-5 parágrafos, com frase-tese
2. **Planilha .xlsx** — 7 abas estratificadas pra você operar e cortar
3. **HTML autocontido** — relatório visual pro cliente/diretor, com identidade fixa

**Foco analítico:** explicar *por que* a restrição existe e *onde mexer primeiro* pra
destravar receita, não apenas descrever números.

---

## Passo 0 — Detectar o modo de operação

Antes de qualquer análise, identifique em qual modo a skill vai rodar:

**Modo A — Mídia pura.** Usuário entregou apenas dados de Meta + projeção. Análise vai até
CPL e diagnóstico de criativo/público/página. Não calcula MQL nem aplica TOC priorizando MQL.

**Modo B — Mídia + funil parcial.** Usuário entregou dados de Meta + projeção + CSV do CRM
com UTMs. Análise vai até MQL por criativo/conjunto/público. Aplica TOC priorizando MQL na
hierarquia de proximidade da receita.

**Regra de detecção:**
- Se faltar projeção em qualquer modo → **TRAVA** e pede `templates/projecao-modelo.xlsx`
- Se vier CSV de CRM **sem dados de Meta** → redirecione: "Para análise de CRM use a skill
  `crm-inside-sales`. Esta skill exige dados de Meta como input principal."
- Se vier CSV de CRM **sem UTMs** em parte significativa dos leads → segue em Modo B mas
  sinaliza explicitamente no relatório a cobertura UTM e o impacto na confiança da análise

**No início da execução, pergunte ao usuário:**
> "Identifiquei que você quer análise de [CLIENTE]. Confirma o ID/nome da conta do MCP?
> E você quer: (a) só resumo no chat + planilha .xlsx (mais rápido), ou
> (b) os três artefatos incluindo HTML completo (mais completo, mais demorado)?"

---

## Passo 1 — Validar inputs antes de qualquer cálculo

### 1.1 Validação da projeção (obrigatória)

A projeção é a régua de tudo. **Sem projeção, a skill não roda.** A regra "está acima ou
abaixo da média" é sempre relativa à projeção, nunca a benchmark de mercado ou percentil
do dataset.

Métricas obrigatórias na projeção (varia conforme funil — ver `referencias/metricas-por-funil.md`):

**Funil de Lead/Performance:**
Valor investido, CPM, Impressões, Frequência, Alcance, CTR, Cliques no link, CPC,
LP View Rate, Visitas na página de destino, Custo por visita, Taxa Visita→Lead, Lead,
CPL. Em Modo B adicione: Taxa Lead→MQL, MQL, CPMQL.

**Funil de Vídeo:**
Valor investido, Impressões, Frequência, Alcance, Visualizações 3s, Taxa 3s, Thruplays,
Taxa Thruplay, Retenção 25/50/75/100%, Tempo médio assistido.

**Funil de Branding/Engajamento:**
Impressões, Frequência, Alcance, Engajamento, Curtidas, Comentários, Compartilhamentos,
Salvamentos, Cliques no link do perfil, Visitas ao perfil, Novos seguidores, Custo por
seguidor.

**Se faltar qualquer métrica obrigatória → TRAVA e mostra ao usuário exatamente o que falta.**

### 1.2 Validação dos dados de Meta

Mínimas obrigatórias quando vier por CSV exportado:
Valor investido, CPM, Impressões, Frequência, Alcance, CTR, Cliques no link, CPC,
LP View Rate, Visitas na página de destino, Custo por visita, Taxa Visita→Lead, Lead, CPL.

Se vier por MCP da Meta, todas as métricas geralmente vêm. Se alguma faltar, sinaliza e segue.

### 1.3 Validação das UTMs (apenas Modo B)

UTMs obrigatórias: `utm_source`, `utm_medium`, `utm_campaign`, `utm_content`, `utm_term`, `fbclid`.

**Se faltarem UTMs em parte dos leads:** segue a análise mas sinaliza explicitamente:
> "X% dos leads do período não possuem UTM completa. A análise de MQL por criativo/conjunto
> está limitada a Y leads com rastreamento confiável."

### 1.4 Identificação do critério de MQL (apenas Modo B)

MQL varia por cliente. Tente inferir do CSV:
- Se houver coluna explícita de **estágio/etapa** com valor "MQL" ou similar → usa estágio
- Se houver campos qualificadores nominais (ex: "tem CNPJ", "faturamento mensal") → tenta inferir
  a regra lógica (ex: tem CNPJ = Sim AND faturamento >= R$ 100k = MQL)

**Em qualquer caso de dúvida, pergunte ao usuário ANTES de prosseguir:**
> "Identifiquei estes campos qualificadores: [lista]. Confirma que o critério de MQL é
> [regra inferida]? Ou prefere usar o estágio [X] do CRM?"

### 1.5 Detecção de duplicatas e inconsistências

- **Leads duplicados:** conta uma vez e sinaliza no relatório a quantidade duplicada
- **Eventos fora de ordem** (ex: venda antes de MQL): sinaliza e exclui da análise de funil
- **Valores claramente inconsistentes** (ex: mais leads que cliques): tenta inferir e segue;
  se não der, sinaliza e trava

---

## Passo 2 — Separar campanhas por objetivo

**Nunca misture campanhas de objetivos diferentes na mesma análise comparativa.** Os funis
de avaliação são distintos.

Identifique o objetivo de cada campanha por:
1. Coluna explícita "Objetivo" no CSV/MCP
2. Nomenclatura no nome da campanha (tags, sufixos como _LEAD, _VID, _BRAND)
3. Métricas predominantes (se tem CPL meta, é Lead; se tem ThruPlay, é Vídeo)

Categorias:
- **Lead/Performance** → aplica funil de Lead (Passo 4)
- **Vídeo/Branding** → aplica funil de Vídeo (Passo 4 alternativo)
- **Engajamento/Perfil** → aplica funil de Branding (Passo 4 alternativo)
- **Testes isolados** (tags/nomenclatura específica) → análise separada

**Para campanhas de Facebook Forms ou Messaging Conversations Started:** NÃO trate baixo
LP View Rate como problema — o lead acontece sem visita à página. Use Taxa Cliques→Lead
direto.

---

## Passo 3 — Calcular o funil consolidado e por estratificação

### 3.1 Visão hierárquica obrigatória: Campanha > Conjunto > Criativo

A visão analítica principal é **sempre** Campanha > Conjunto > Criativo. Calcule as métricas
do funil em cada nível.

**Estratificação adicional:** o mesmo criativo pode estar em múltiplos anúncios em conjuntos
diferentes. Trate cada combinação Conjunto+Criativo como linha distinta na análise — o
desempenho muda conforme o público.

### 3.2 Métricas a calcular (Modo A e B)

Ver `referencias/metricas-por-funil.md` pra lista completa por tipo de funil.

**Em Modo B, adicione obrigatoriamente:**
- Lead → MQL por criativo/conjunto/público
- Custo por MQL por criativo/conjunto/público
- MQL por campanha, conjunto e criativo
- MQL por público
- Taxa Lead → MQL por canal (sempre Meta nesta skill, mas a coluna fica pra cruzamento futuro)

### 3.3 Quebras obrigatórias (quando há variância significativa)

Avalie e inclua no relatório quando a variância entre grupos for relevante:
- Idade e gênero
- Posicionamento e dispositivo
- Região
- Públicos inclusos e excluídos (vem da configuração do anúncio)

**Critério de "variância significativa":** se a diferença entre o melhor e o pior grupo for
> 30% em qualquer métrica de proximidade da receita (CPL, CPMQL), inclua a quebra.
Caso contrário, omita pra não inflar o relatório.

---

## Passo 4 — Diagnóstico da restrição (Theory of Constraints)

Esta é a etapa central da skill. Ver `referencias/regras-toc.md` pra metodologia detalhada.

### 4.1 Hierarquia de proximidade da receita

A relevância de cada métrica obedece à ordem (do menos pro mais relevante):

```
CPM → CTR → CPC → CPLPV → CPL → CPMQL → CPSQL → CAC → ROAS/ROI
```

**Quando dois sinais brigam, ganha o mais próximo da receita.** Exemplo: criativo com CPL
ótimo mas CTR ruim → CPL ganha (mais próximo da receita), criativo é vencedor.

### 4.2 Identificação da restrição global (única)

A restrição global é uma única frase que sintetiza onde está o maior bloqueio de receita
da operação no período. Ela vira o **título-tese do relatório** (ver Passo 7).

Padrão de identificação:
1. Compare cada métrica do realizado contra a projeção
2. Identifique a maior queda em métricas próximas à receita (priorize as últimas da hierarquia)
3. Avalie o volume afetado (quanto de receita potencial está travado naquele ponto)
4. A restrição global é o ponto que combina **maior gap vs projeção** + **maior volume
   afetado** + **maior proximidade da receita**

**Se não conseguir formular tese clara → TRAVA e pede mais dado/contexto.**
Relatório sem tese é descrição, não diagnóstico.

### 4.3 Identificação das restrições locais (top 3, ou mais se relevantes)

Restrições locais são gargalos por canal/campanha/criativo/público que travam o funil em
pontos específicos. Liste as 3 mais relevantes (ou mais, se forem genuinamente críticas
pra destravar receita).

Cada restrição local deve responder: **onde mexer primeiro**, não apenas onde está o problema.

### 4.4 Diagnóstico do gargalo principal — exemplos

- **CTR baixo vs projeção** → problema de criativo (capa, copy, gancho)
- **CPC alto vs projeção** → problema de eficiência de mídia (público amplo demais, leilão saturado)
- **LP View Rate baixo vs projeção** → problema de página (carregamento, mismatch de promessa)
- **Taxa Visita→Lead baixa vs projeção** → problema de formulário/oferta
- **Lead alto + CPMQL alto vs projeção** → problema de qualificação (público, oferta, criativo
  atraindo lead errado)
- **Lead alto + MQL alto + venda baixa** (em Modo B com CRM) → problema comercial/operação
  (apontar e indicar `crm-inside-sales` pra análise profunda)

**Sempre escreva impacto estimado em receita** quando possível. Ex: "Se CPMQL voltar à
projeção, geração mensal de MQL aumentaria de X para Y, equivalente a R$ Z em receita
projetada considerando ticket médio histórico."

---

## Passo 5 — Classificar criativos

Ver `referencias/regras-classificacao.md` pra critério detalhado.

### 5.1 Critério "vencedor" (combinação obrigatória)

Criativo vencedor combina:
- Volume relevante de leads (pelo menos não estatisticamente desprezível — sinaliza se for
  amostra pequena com "sem amostragem suficiente")
- CPL **abaixo da projeção** (não da média do dataset)
- Boa Taxa Cliques→Lead vs projeção
- Sinais aceitáveis de CTR, CPC e LPV vs projeção
- Em Modo B: CPMQL **abaixo da projeção** (prioritário sobre CPL pela hierarquia de receita)

### 5.2 Critério "para revisar/reduzir/pausar"

Criativo a revisar combina algum de:
- Gasto relevante sem lead
- CPL acima da projeção
- Baixa Taxa Cliques→Lead vs projeção
- Fadiga por frequência (frequência alta vs projeção, com queda de CTR concomitante)
- CTR baixo, CPC alto vs projeção
- Desalinhamento entre promessa do anúncio e página/formulário
- Em Modo B: CPMQL alto mesmo com CPL ok (lead ruim — qualidade/público errado)

### 5.3 Ação recomendada (sempre explícita)

Para cada criativo classificado, escolha **uma** ação:
- **Escalar** — vencedor com headroom de orçamento
- **Manter** — performando dentro da projeção, sem sinal de fadiga
- **Reduzir** — performando abaixo mas com algum sinal aproveitável
- **Pausar** — performando muito abaixo e sem sinal de recuperação
- **Duplicar variações** — vencedor com fadiga próxima (testar variações antes de fadigar)
- **Revisar criativo** — problema claro de criativo (CTR ruim)
- **Revisar público** — problema de público (CPMQL alto com CPL ok)
- **Revisar página/formulário** — problema downstream do clique
- **Revisar tracking** — UTMs incompletas, conversão off, etc.

---

## Passo 6 — Plano 5W1H de 7 dias

Ver `referencias/5w1h-formato.md` pra template completo.

### 6.1 Estrutura

Tabela com 7 colunas obrigatórias: **What | Why | Where | Who | When | How | Impacto esperado**

### 6.2 Quantidade de ações

Entre 3 e 7 ações, priorizadas por impacto em receita (a primeira é sempre a que destrava a
restrição global). Não force 7 ações se forem só 4 que importam.

### 6.3 Conteúdo

- **What** — ação concreta, verbo no infinitivo (ex: "Pausar 4 criativos com CPMQL > 2x projeção")
- **Why** — vínculo direto com a restrição identificada
- **Where** — onde executar (Meta Ads, página, formulário, CRM, etc.)
- **Who** — quem executa (Media Buyer, Growth Ops, Designer, CRM Owner, etc.)
- **When** — janela em dias (D1, D1-D2, D1-D7)
- **How** — instrução tática **e** estratégica (não só "subir variação", mas "subir 3 variações
  testando ângulo de benefício X com formato Reels 9:16, mantendo público vencedor Y")
- **Impacto esperado** — resultado projetado, preferencialmente em receita ou métrica próxima

### 6.4 Audiência do plano

Plano serve **tanto pra você quanto pra cliente**. Escreva direto, sem suavizar problemas
graves, mas com tom profissional. É legítimo escrever coisas como "esse cliente está
queimando dinheiro com criativo fadigado há 30 dias" quando os dados sustentarem.

---

## Passo 7 — Gerar os outputs

### 7.1 Resumo no chat (sempre primeiro)

Formato:
- **Primeira pessoa de analista** ("identifiquei...", "minha leitura é...", "recomendo...")
- **Sem bullets com hífen** (regra fixa de tom do Jean)
- **3-5 parágrafos**
- Estrutura: frase-tese → restrição global e top 3 locais → 2-3 ações mais críticas do
  5W1H → próximos passos
- Ver `exemplos/exemplo-resumo-chat.md`

### 7.2 Planilha .xlsx (sempre gerada)

7 abas obrigatórias na ordem (ver `templates/planilha-output-estrutura.md`):

1. **Diagnóstico** — restrição global, top 3 locais, frase-tese, KPIs principais
2. **Projetado vs Realizado** — comparação métrica a métrica com variação % e status
3. **Funil de mídia** — todas as métricas do funil, de impressão a MQL (em Modo B)
4. **Por criativo** — Campanha > Conjunto > Criativo com classificação
5. **Quebras** — idade/gênero, posicionamento, região, públicos (blocos na mesma aba)
6. **5W1H** — plano de ação no formato What/Why/Where/Who/When/How/Impacto
7. **Dados brutos** — tabela achatada pra cortes adicionais

Use a skill `xlsx` pra criar — leia o SKILL.md dela antes.

### 7.3 HTML completo (apenas se usuário escolher opção (b) no Passo 0)

Estrutura adaptativa (seções obrigatórias + condicionais):

**Sempre presentes:**
- Header com título-tese
- Resumo executivo
- Metodologia (curta — 2-3 parágrafos)
- Projetado vs Realizado
- Diagnóstico da restrição principal (global + locais)
- Indicadores gerais
- Meta por criativo (Campanha > Conjunto > Criativo)
- Criativos vencedores
- Criativos para reduzir ou revisar
- Plano 5W1H de 7 dias

**Condicionais (incluir quando relevância detectada):**
- Quebras por públicos inclusos/excluídos
- Quebras por idade/gênero
- Quebras por posicionamento/dispositivo
- Quebras por região
- Leitura de CRM ou higiene comercial (apenas Modo B, e curta — direciona pra `crm-inside-sales`)

**Identidade visual:** usa `templates/relatorio.css` (CSS externalizado, não reescrever
inline). HTML usa `templates/relatorio-estrutura.html` como base com placeholders.

---

## Regras invioláveis (não negocie)

1. **Projeção é obrigatória.** Sem ela, trava.
2. **Hierarquia de proximidade da receita** sempre rege priorização. CAC > CPSQL > CPMQL >
   CPL > CPLPV > CPC > CTR > CPM.
3. **Restrição global é única**, com frase-tese clara. Se não conseguir formular tese, trava.
4. **Restrições locais são top 3** (ou mais quando todas forem genuinamente críticas).
5. **Preservar nomes originais** de campanhas, conjuntos e anúncios.
6. **Evitar redundância de tabelas.** Se a visão por criativo já mostra campanha e conjunto,
   não crie tabelas separadas a menos que pedido.
7. **Modo B exige UTMs** — sem rastreamento, MQL por criativo é cego.
8. **Em campanhas de Facebook Forms / Messaging:** baixo LPV não é problema principal.
9. **Não comparar Projetado vs Realizado de escopos diferentes.** Mesmo período, canal,
   objetivo, escopo, produto, serviço.
10. **Quando detectar problema de CRM em Modo B:** aponta brevemente e direciona pra
    `crm-inside-sales`. Esta skill não substitui a análise profunda de funil comercial.

---

## Tom e formatação

- Primeira pessoa de analista no resumo do chat
- Sem bullets com hífen no resumo do chat (em listas dentro de planilha/HTML pode usar)
- Direto, profissional, com licença pra apontar desperdício quando os dados sustentarem
- Janela default: **MTD (Mês corrente até hoje)** quando o usuário não especificar
- Escreva números sempre com formato BR (R$ 1.234,56 / 25,3% / 1.234 leads)

---

## Checklist antes de entregar

- [ ] Modo identificado (A ou B) e comunicado ao usuário
- [ ] ID/conta da Meta confirmado
- [ ] Projeção validada (todas as métricas presentes)
- [ ] UTMs validadas (se Modo B), cobertura sinalizada
- [ ] Critério de MQL confirmado com usuário (se Modo B)
- [ ] Campanhas separadas por objetivo
- [ ] Funil consolidado calculado
- [ ] Quebras avaliadas e incluídas se variância > 30%
- [ ] Restrição global identificada com frase-tese clara
- [ ] Top 3 restrições locais identificadas
- [ ] Criativos classificados com ação recomendada explícita
- [ ] Plano 5W1H com 3-7 ações priorizadas por impacto em receita
- [ ] Resumo no chat em prosa primeira pessoa, sem hífen
- [ ] Planilha .xlsx com 7 abas geradas
- [ ] HTML gerado (apenas se usuário escolheu opção b)
- [ ] CSS do HTML referencia arquivo externo (não inline) pra economia de tokens
