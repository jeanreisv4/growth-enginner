# Métricas por Funil

Esta referência define **todas as métricas obrigatórias** que a skill deve calcular, agrupar
e comparar contra a projeção em cada tipo de funil. A separação por funil é inegociável —
nunca misture métricas de objetivos diferentes na mesma análise comparativa.

---

## Funil de Lead / Performance

Use quando o objetivo da campanha é **geração de leads, conversões ou performance direta**.
Inclui campanhas com objetivo "Lead", "Conversões", "Tráfego pra LP de captura",
"Facebook Lead Ads", "Messaging Conversations Started".

### Métricas obrigatórias (Modo A — só Meta)

Topo do funil:
- Valor investido (R$)
- CPM (custo por mil impressões)
- Impressões
- Frequência (%)
- Alcance (pessoas únicas atingidas)

Engajamento de mídia:
- CTR (taxa de clique no link)
- Cliques no link
- CPC (custo por clique)

Engajamento de página:
- LP View Rate (taxa de visita à página de destino)
- Visitas na página de destino
- Custo por visita na página de destino

Conversão:
- Taxa Visita → Lead (também aplicável em LP, Facebook Forms, conversa iniciada,
  clique para lead)
- Lead (volume)
- Custo por Lead (CPL)

UTMs (sempre presentes nos URLs dos anúncios):
- utm_source
- utm_medium
- utm_campaign
- utm_content
- utm_term
- fbclid

### Métricas adicionais (Modo B — Meta + CRM com UTMs)

- Taxa Lead → MQL
- MQL (volume) — por campanha, conjunto, criativo, público
- Custo por MQL (CPMQL)

### Atenção pra Facebook Forms / Messaging Conversations Started

Em campanhas onde o lead acontece **dentro do Meta** (formulário nativo, conversa no
WhatsApp/Messenger via anúncio), a métrica de LP View Rate **não se aplica**. Substitua na
análise por:
- Taxa Cliques → Lead (direto)
- Não trate baixo LPV como problema principal nestas campanhas

---

## Funil de Vídeo / Branding

Use quando o objetivo é **visualização de vídeo, awareness ou consideração via vídeo**.
Inclui campanhas com objetivo "Visualizações de vídeo", "ThruPlay", "Reconhecimento via
vídeo".

### Métricas obrigatórias

Cobertura:
- Valor investido (R$)
- Impressões
- Frequência (%)
- Alcance

Visualização:
- Visualizações de 3 segundos
- Taxa de visualização de 3 segundos
- ThruPlays (visualizações de 15 segundos OU 97% do vídeo, o que vier antes)
- Taxa de ThruPlay (visualizações únicas de vídeo / impressões)

Retenção (curva de atenção):
- Taxa de retenção 25%
- Taxa de retenção 50%
- Taxa de retenção 75%
- Taxa de retenção 100%

Tempo:
- Tempo médio assistido (segundos)

### Regra crítica

**Não avalie campanhas de vídeo por CPL, a menos que elas também tenham objetivo explícito
de lead.** A medição de sucesso é retenção e ThruPlay, não conversão direta.

Quando uma campanha de vídeo tiver dupla função (vídeo + lead), avalie pelos dois funis em
paralelo no relatório, em seções distintas.

---

## Funil de Branding / Engajamento

Use quando o objetivo é **reconhecimento de marca, engajamento na página, crescimento de
seguidores no perfil**.

### Métricas obrigatórias

Cobertura:
- Impressões
- Frequência (%)
- Alcance

Engajamento:
- Engajamento total
- Curtidas
- Comentários
- Compartilhamentos
- Salvamentos

Perfil:
- Cliques no link do perfil
- Visitas ao perfil
- Novos seguidores
- Custo por seguidor

### Regra crítica

**Não avalie campanhas de branding por CPL, CPMQL ou ROAS.** A medição de sucesso é
engajamento qualificado e crescimento de comunidade. Comparar branding com performance é
comparar laranjas com bananas.

---

## Tabela resumo — Métricas por funil

| Métrica                         | Lead/Performance | Vídeo | Branding/Engajamento |
|---------------------------------|------------------|-------|----------------------|
| Valor investido                 | ✓ obrigatória    | ✓     | ✓                    |
| CPM                             | ✓                | (opc) | (opc)                |
| Impressões                      | ✓                | ✓     | ✓                    |
| Frequência                      | ✓                | ✓     | ✓                    |
| Alcance                         | ✓                | ✓     | ✓                    |
| CTR                             | ✓                | -     | -                    |
| Cliques no link                 | ✓                | -     | -                    |
| CPC                             | ✓                | -     | -                    |
| LP View Rate                    | ✓ (exceto Forms) | -     | -                    |
| Custo por LP View               | ✓ (exceto Forms) | -     | -                    |
| Taxa Visita → Lead              | ✓                | -     | -                    |
| Lead                            | ✓                | -     | -                    |
| CPL                             | ✓                | -     | -                    |
| Taxa Lead → MQL (Modo B)        | ✓                | -     | -                    |
| MQL (Modo B)                    | ✓                | -     | -                    |
| CPMQL (Modo B)                  | ✓                | -     | -                    |
| Visualizações 3s                | -                | ✓     | -                    |
| ThruPlay                        | -                | ✓     | -                    |
| Retenção 25/50/75/100%          | -                | ✓     | -                    |
| Tempo médio assistido           | -                | ✓     | -                    |
| Engajamento total               | -                | -     | ✓                    |
| Curtidas/Comentários/Compart.   | -                | -     | ✓                    |
| Salvamentos                     | -                | -     | ✓                    |
| Cliques no link do perfil       | -                | -     | ✓                    |
| Visitas ao perfil               | -                | -     | ✓                    |
| Novos seguidores                | -                | -     | ✓                    |
| Custo por seguidor              | -                | -     | ✓                    |
